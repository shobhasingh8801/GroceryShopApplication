import { Link, NavLink, Outlet } from 'react-router-dom';
import { useContext } from 'react';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTruckFast, faCartPlus, faRightFromBracket } from '@fortawesome/free-solid-svg-icons';
import { useCart, CartContext } from '../CartContext';

import './css/header.css';
import { TbBoxMargin } from 'react-icons/tb';

const Header = () => {
    const { totalItems } = useCart();  //Get total items from context
    const userData = JSON.parse(localStorage.getItem('userData'));
    const userName = userData && userData.name;  // Get username from localStorage
    const { admin } = useContext(CartContext);

    const handleLogout = () => {
        localStorage.removeItem('userData');
        localStorage.removeItem('authToken');
        window.location.reload(); // Reload page to reflect logout
    };

    return (
        <>
            <div className='Head-fix'>
                <nav className="navbar">
                    <div style={{ fontSize: "22px", marginLeft: "100px", color: "#007bff", fontWeight:"bolder",fontFamily:"-moz-initial" }}><Link to="/">Online Grocery Shop <FontAwesomeIcon icon={faTruckFast} /></Link></div>
                    {/* <div><FontAwesomeIcon icon={faCircleUser} color='white' /> <Link to="/Login">Login</Link></div> */}
                    {/* <div><FontAwesomeIcon icon={faCirclePlus} color='white' /> <Link to="/AddProduct">Add Product</Link></div> */}
                    {/* <div className='categories'>
                    <div><Link to="/FruitsVeg">Fruits & Vegetables</Link></div>
                    <div><Link to="/Pulses">Pulses</Link></div>
                    <div><Link to="/DryFruits">Dry Fruits</Link></div>
                    <div><Link to="/OilsGhee">Cooking Oil & Ghee</Link></div>
                    <div><Link to="/FlourGrains">Flours & Grains</Link></div>
                    <div><Link to="/Rice">Rice</Link></div>
                    <div><Link to="/MasalaSpices">Masala & Spices</Link></div>
                    <div><Link to="/Others">Salt, Sugar & Others</Link></div>
                </div> */}

                    <div className='cart' style={{marginRight:"50px"}}>
                        <Link to="/Cart" style={{ fontSize: "20px", position: 'relative', display: 'inline-block',float: "right" }}><FontAwesomeIcon icon={faCartPlus} />
                            {totalItems > 0 && (<span style={badgeStyle}>{totalItems}</span>)}
                        </Link>
                        
                        {userName ? (
                            <span style={{ color: "#007bff",float: "right", marginRight:"50px" }}><strong>{userName}</strong>  <FontAwesomeIcon icon={faRightFromBracket} onClick={handleLogout} style={{cursor:"pointer"}} title='Click here to Logout!'/></span>  // Show username if logged in
                        ) : (
                            <span style={{ color: "#007bff",float: "right", marginRight:"50px" }}><Link to="/Login">Login</Link></span>  // Else show login link
                        )}

                         <span style={{ color: "#007bff",float: "right", marginRight:"50px" }}><Link to="/AboutUs">About Us</Link></span>
                        {admin && 
                            <span style={{ color: "#007bff",float: "right", marginRight:"50px" }}><Link to="/AddProduct">Add Product</Link></span>
                        }

                    </div>
                </nav>

                <div className='categories'>
                    <div>
                        <NavLink to="/FruitsVeg" className={({ isActive }) => isActive ? 'category-link active' : 'category-link'}>
                            Fruits & Vegetables
                        </NavLink>
                    </div>
                    <div>
                        <NavLink to="/Pulses" className={({ isActive }) => isActive ? 'category-link active' : 'category-link'}>
                            Pulses
                        </NavLink>
                    </div>
                    <div>
                        <NavLink to="/DryFruits" className={({ isActive }) => isActive ? 'category-link active' : 'category-link'}>
                            Dry Fruits
                        </NavLink>
                    </div>
                    <div>
                        <NavLink to="/OilsGhee" className={({ isActive }) => isActive ? 'category-link active' : 'category-link'}>
                            Cooking Oil & Ghee
                        </NavLink>
                    </div>
                    <div>
                        <NavLink to="/FlourGrains" className={({ isActive }) => isActive ? 'category-link active' : 'category-link'}>
                            Flours & Grains
                        </NavLink>
                    </div>
                    <div>
                        <NavLink to="/Rice" className={({ isActive }) => isActive ? 'category-link active' : 'category-link'}>
                            Rice
                        </NavLink>
                    </div>
                    <div>
                        <NavLink to="/MasalaSpices" className={({ isActive }) => isActive ? 'category-link active' : 'category-link'}>
                            Masala & Spices
                        </NavLink>
                    </div>
                    <div>
                        <NavLink to="/Others" className={({ isActive }) => isActive ? 'category-link active' : 'category-link'}>
                            Salt, Sugar & Others
                        </NavLink>
                    </div>
                </div>


            </div>
            <Outlet />
        </>

    );
};

// Optional: Add a red badge style for the cart count
const badgeStyle = {
    position: 'absolute',
    top: '-8px',
    right: '-10px',
    background: 'red',
    color: 'white',
    borderRadius: '50%',
    padding: '2px 6px',
    fontSize: '12px',
    fontWeight: 'bold'
};

export default Header;