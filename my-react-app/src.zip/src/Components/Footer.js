import { Link } from "react-router-dom";

import './css/footer.css';
import ContactUs from "./ContactUs";
import AboutUs from "./AboutUs";

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { FaFacebook, FaInstagram, FaTwitter, FaLinkedin } from '@fortawesome/free-solid-svg-icons';
import { FaFacebook, FaInstagram, FaTwitter, FaLinkedin } from "react-icons/fa";

const Footer = () => {

    const Show = () => {
        document.getElementById("contact").style.display = "block";
    };
    return (
        <>
            <div className="footer">
                <div>
                    <h3>About</h3>
                    <p>We are revolutionizing e-commerce by making the stuff most important to you, available to you in a blink of your eye.</p>
                </div>
                <div className="hover">
                    <h3>Usefull Links</h3>
                    <p onClick={Show}>Contact Us</p>
                    <p><Link to="/AboutUs">About Us</Link></p>
                </div>
                <div>
                    <h3>Social handle</h3>
                    <p><FontAwesomeIcon icon={FaFacebook} />Facebook</p>
                    <p><FontAwesomeIcon icon={FaInstagram} />Instagram</p>
                    <p><FontAwesomeIcon icon={FaTwitter} />Twitter</p>
                    <p><FontAwesomeIcon icon={FaLinkedin} />Linkedin</p>
                </div>
                <div className="hover">
                    <h3>Product Categories</h3>
                    <p><Link to="/FruitsVeg">Fruits & Vegetables</Link></p>
                    <p><Link to="/Pulses">Pulses</Link></p>
                    <p><Link to="/DryFruits">Dry Fruits</Link></p>
                    <p><Link to="/OilsGhee">Oil & Ghee</Link></p>
                    <p><Link to="/FlourGrains">Flours & Grains</Link></p>
                    <p><Link to="/Rice">Rice</Link></p>
                    <p><Link to="/MasalaSpices">Masala & Spices</Link></p>
                    <p><Link to="/Others">Salt, Sugar & Others</Link></p>
                </div>
            </div>
            <ContactUs />
        </>

    );
};

export default Footer;